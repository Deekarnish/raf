import React, { useContext, useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import DUTMasterListToolbar from "./DUTMasterListToolbar";
import DUTMasterListHead from "./DUTMasterListHead";
import { DUTLibrary, Order } from "../../types";
import Paper from "@mui/material/Paper";
import { stableSort, getComparator } from "../../utils";
import DUTType from "../../assets/images/DUTType.png";
import { Divider, Grid } from "@mui/material";
import Moment from "react-moment";
import { createRequest } from "../../services/ApiServices";
import { ProgressContext } from "../../context/ProgressContext";
import back from "../../../src/assets/images/back.png"
import { Link } from "react-router-dom";

const ROW_HEIGHT = 53;

const DUTListTable = styled(Paper)`
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #dfe0eb;
  padding: 15px 0;
  margin-top: 35px;
`;

const ItemDivider = styled(Divider)`
  margin: 0 !important;
  border-color: #fff;
  border-width: 1px;
`;

function DUTMasterList() {
  const [order, setOrder] = React.useState<Order>("asc");
  const [orderBy, setOrderBy] = React.useState<keyof DUTLibrary>("name");
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [filteredRows, setFilteredRows] = useState<DUTLibrary[]>([]);
  const { setProgressData } = useContext(ProgressContext);

  useEffect(() => {
    getDUT();
  }, []);

  const getDUT = () => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "dut",
      method: "fetch_all",
    })
      ?.then(async (res) => {
        setFilteredRows(res.data);
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof DUTLibrary
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - filteredRows.length) : 0;

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    setSearchTerm(inputValue);

    if (inputValue === "") {
      getDUT(); // reset to full data when search term is cleared
    }
  };

  const handleFilterData = () => {
    const filteredData = filteredRows.filter((item) =>
      item.dut_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.manufacturer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.user.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredRows(filteredData);
  };

  return (
    <>
      <Box sx={{ width: "100%" }} color="secondary">
        <Link to={"/nodesetup"}>
          <div
            style={{
              marginTop: "10px",
              display: "flex",
              alignItems: "center",
              gap: "5px",
              cursor: "pointer",
              color: "#000",
              textDecoration: "none",
            }}
          >
            <img src={back} alt="back" width={20} height={20} />
            <h4 style={{ textDecoration: "none" }}>Node Setup</h4>
          </div>
        </Link>
        <DUTListTable sx={{ width: "100%", mb: 0 }} color="secondary">
          <DUTMasterListToolbar
            searchTerm={searchTerm}
            handleSearchChange={handleSearchChange}
            handleFilterData={handleFilterData}
          />
          <TableContainer color="secondary">
            <Table
              sx={{ minWidth: 750, borderColor: "#DFE0EB" }}
              aria-labelledby="tableTitle"
              size={"medium"}
            >
              <DUTMasterListHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
                rowCount={filteredRows.length}
              />
              <TableBody>
                {
                  stableSort<any>(filteredRows, getComparator(order, orderBy))
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((row: DUTLibrary, index: number) => {
                      return (
                        <TableRow hover key={index}>
                          <TableCell>
                            <Grid container direction="row">
                              <Grid item xs={4}>
                                <img src={DUTType} alt="DUTType" />
                              </Grid>

                              <Grid item xs={8}>
                                <Grid item>{row.dut_type}</Grid>
                                <Grid
                                  item
                                  sx={{
                                    fontSize: "12px",
                                    color: "#C5C7CD",
                                    paddingTop: "5px",
                                  }}
                                >
                                  Updated{" "}
                                  <Moment fromNow ago>
                                    {row.update}
                                  </Moment>{" "}
                                  ago
                                </Grid>
                              </Grid>
                            </Grid>
                          </TableCell>
                          <TableCell align="left">{row.name}</TableCell>

                          <TableCell align="left">{row.model}</TableCell>
                          <TableCell align="left">{row.manufacturer}</TableCell>
                          <TableCell align="left">{row.serial}</TableCell>
                          <TableCell align="left">{row.firmware}</TableCell>
                          <TableCell align="left">
                            <Grid container direction="column">
                              <Moment format="MMM DD, YYYY">
                                {row.update}
                              </Moment>
                              <Grid
                                item
                                sx={{
                                  fontSize: "12px",
                                  color: "#C5C7CD",
                                  paddingTop: "5px",
                                }}
                              >
                                <Moment format="hh:mm">{row.update}</Moment>
                              </Grid>
                            </Grid>
                          </TableCell>
                          <TableCell align="left">{row.user}</TableCell>
                        </TableRow>
                      );
                    })}
                {emptyRows > 0 && (
                  <TableRow
                    style={{
                      height: ROW_HEIGHT * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={filteredRows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </DUTListTable>
      </Box>
    </>
  );
}

export default DUTMasterList;
