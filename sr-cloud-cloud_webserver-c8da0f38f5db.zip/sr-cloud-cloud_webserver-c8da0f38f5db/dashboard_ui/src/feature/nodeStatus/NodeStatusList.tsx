import React, { useContext, useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import TablePagination from "@mui/material/TablePagination";
import NodeStatusListToolbar from "./NodeStatusListToolbar";
import { NodeData, NodeSetupStatusLabel, Views } from "../../types";
import Paper from "@mui/material/Paper";
import ListView from "./ListView";
import CardView from "./CardView";
import { createRequest } from "../../services/ApiServices";
import { ProgressContext } from "../../context/ProgressContext";


const NodeListTable = styled(Paper)`
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #dfe0eb;
  padding: 15px 0;
  margin-top: 35px;
`;

function NodeStatusView() {
  const [page, setPage] = React.useState(0);
  const [rows, setRows] = useState<any[]>([]);
  const [filteredRows, setFilteredRows] = useState<any[]>([]);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [searchTerm, setSearchTerm] = useState('');
  const [rowsPerPageOptions, setRowsPerPageOptions] = React.useState([5, 10, 25]);
  const [view, setView] = React.useState(Views.list);
  
  // Separate state for rowsPerPage in list and card views
  const [listRowsPerPage, setListRowsPerPage] = React.useState(5);
  const [cardRowsPerPage, setCardRowsPerPage] = React.useState(20);

  const { setProgressData } = useContext(ProgressContext);

  useEffect(() => {
    getNodes();
  }, []);

  const getNodes = () => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "node",
      method: "fetch_all",
    })
      ?.then(async (res) => {
        setFilteredRows(res?.data);
        setRows(res?.data);
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };

  const changeView = (newView: Views) => {
    if (newView === Views.card) {
      setCardRowsPerPage(rowsPerPage);  
      setRowsPerPage(cardRowsPerPage);  
      setRowsPerPageOptions([20, 40, 60]);
    } else {
      setListRowsPerPage(rowsPerPage);  
      setRowsPerPage(listRowsPerPage); 
      setRowsPerPageOptions([5, 10, 25]);
    }
    setView(newView);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newRowsPerPage = parseInt(event.target.value, 10);
    setRowsPerPage(newRowsPerPage);
    setPage(0);

    if (view === Views.list) {
      setListRowsPerPage(newRowsPerPage);
    } else {
      setCardRowsPerPage(newRowsPerPage);
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    setSearchTerm(inputValue);

    if (inputValue === "") {
      setFilteredRows(rows);
    }
  };
  
  const handleFilterData = () => {
    const searchTermLower = searchTerm.toLowerCase();

    const filteredStatusLabels = Array.from(NodeSetupStatusLabel.entries())
      .filter(([, label]) => label.toLowerCase().includes(searchTermLower))
      .map(([statusId]) => statusId);

    const filterData = filteredRows.filter((item: any) => {
      const statusLabel = NodeSetupStatusLabel.get(item.statusId)?.toLowerCase();
      return (
        item?.nodeIdentifier.toLowerCase().includes(searchTermLower) ||
        item?.serialNumber.includes(searchTerm) ||
        item?.templateName.toLowerCase().includes(searchTermLower) || 
        (statusLabel && statusLabel.includes(searchTermLower))
      );
    });

    setFilteredRows(filterData);
  };

  return (
    <Box sx={{ width: "100%" }} color="secondary">
      <NodeListTable sx={{ width: "100%", mb: 2 }} color="secondary">
        <NodeStatusListToolbar action={changeView} handleSearchChange={handleSearchChange} searchTerm={searchTerm} handleFilterData={handleFilterData} />
        {view === Views.list && (
          <ListView rows={filteredRows} page={page} rowsPerPage={rowsPerPage} />
        )}
        {view === Views.card && (
          <CardView rows={filteredRows} page={page} rowsPerPage={rowsPerPage} />
        )}
        <TablePagination
          rowsPerPageOptions={rowsPerPageOptions}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </NodeListTable>
    </Box>
  );
}

export default NodeStatusView;



