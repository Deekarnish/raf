import * as React from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableRow from "@mui/material/TableRow";
import NodeStatusListHead from "./NodeStatusListHead";
import {
  NodeData,
  NodeSetupStatus,
  NodeSetupStatusLabel,
  Order,
} from "../../types";
import { stableSort, getComparator } from "../../utils";
import nodeStatusIcon from "../../assets/images/nodeStatusIcon.png";
import StatusChipButton from "../../components/StatusChip";
import Moment from "react-moment";
import { Grid } from "@mui/material";
import axios from "axios";
import { useEffect, useState } from "react";
import SearchBar from "../../components/SearchBar";

const ROW_HEIGHT = 53;

interface ListViewProps {
  rows: NodeData[];
  page: number;
  rowsPerPage: number;
}

function ListView({ rows, page, rowsPerPage }: ListViewProps) {
  const [order, setOrder] = React.useState<Order>("asc");
  const [orderBy, setOrderBy] = React.useState<keyof NodeData>("nodeId");
  const [alertMsgData, setAlertMsgData] = useState<any[]>([]);

  const getAlertMsg = async () => {
    let body =
    {
      pageSize: 150,
      pageIndex: 1
    }

    try {
      let res = await axios.post("http://rafqa.us-east-1.elasticbeanstalk.com/node/alerts/all", body, {
        headers: {
          "Content-Type": "application/json",
        },
      })
      setAlertMsgData(res?.data || []);
    } catch (error) {
      console.log("erorrr", error);
    }

  }


  useEffect(() => {
    getAlertMsg()
  }, [])

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof NodeData
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  return (
    <TableContainer color="secondary">
      <Table
        sx={{ minWidth: 750 }}
        aria-labelledby="tableTitle"
        size={"medium"}
      >
        <NodeStatusListHead
          order={order}
          orderBy={orderBy}
          onRequestSort={handleRequestSort}
        />
        <TableBody>
          {rows &&
            rows.length > 0 &&
            stableSort<any>(rows, getComparator(order, orderBy))
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row: NodeData, index: number) => {
                const alertMsg = alertMsgData.find((alert: any) => alert?.nodeId === row?.nodeId);
                return (
                  <TableRow hover key={row.nodeId}>
                    <TableCell>
                      <Grid container direction="row">
                        <Grid item xs={3}>
                          <img src={nodeStatusIcon} alt="nodeStatusIcon" />
                        </Grid>

                        <Grid item xs={9}>
                          <Grid item>{row.nodeIdentifier}</Grid>
                          <Grid
                            item
                            sx={{
                              fontSize: "12px",
                              color: "#C5C7CD",
                              paddingTop: "5px",
                            }}
                          >
                            Updated{" "}
                            <Moment fromNow ago>
                              {row.lastUpdatedOn}
                            </Moment>{" "}
                            ago
                          </Grid>
                        </Grid>
                      </Grid>
                    </TableCell>

                    <TableCell align="left">{row.serialNumber}</TableCell>
                    <TableCell align="left">
                      <Moment format="MMM DD, YYYY">{row.lastUpdatedOn}</Moment>
                    </TableCell>
                    
                    <TableCell align="left">{alertMsg ? alertMsg.alertMessage : "No Alerts"}</TableCell>
                    <TableCell align="left">{row?.totalUptime}</TableCell>
                    <TableCell align="left">
                      <StatusChipButton
                        statusText={NodeSetupStatusLabel.get(row.statusId)}
                        status={NodeSetupStatus[row.statusId]}
                        height={24}
                        width={76}
                        fontSize={9}
                      />
                    </TableCell>

                    
                  </TableRow>
                );
              })}
          {emptyRows > 0 && (
            <TableRow
              style={{
                height: ROW_HEIGHT * emptyRows,
              }}
            >
              <TableCell colSpan={6} />
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default ListView;
