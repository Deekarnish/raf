import {
  TableHead,
  TableRow,
  TableCell,
  TableSortLabel,
  Box,
} from "@mui/material";
import { visuallyHidden } from "@mui/utils";
import { NodeData, Order } from "../../types";

interface HeadCell {
  disablePadding: boolean;
  id: keyof NodeData;
  label: string;
  numeric: boolean;
}

const headCells: readonly HeadCell[] = [
  {
    id: "nodeId",
    numeric: false,
    disablePadding: false,
    label: "Node ID",
  },
  {
    id: "serialNumber",
    numeric: false,
    disablePadding: false,
    label: "Robot Serial No",
  },
  {
    id: "lastUpdatedOn",
    numeric: false,
    disablePadding: false,
    label: "Last Updated",
  },
  {
    id: "alertMessage",
    numeric: false,
    disablePadding: false,
    label: "Alert/Messages",
  },
   {
    id: "totalUptime",
    numeric: false,
    disablePadding: false,
    label: "Total Uptime",
  },
  {
    id: "statusId",
    numeric: false,
    disablePadding: false,
    label: "Status",
  },
];

interface NodeStatusListProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof NodeData
  ) => void;
  order: Order;
  orderBy: string;
}

function NodeStatusListHead(props: NodeStatusListProps) {
  const { order, orderBy, onRequestSort } = props;
  const createSortHandler =
    (property: keyof NodeData) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{color:"#000"}}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
        <TableCell></TableCell>
      </TableRow>
    </TableHead>
  );
}

export default NodeStatusListHead;
