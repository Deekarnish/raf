import React from "react";
import {
  Backdrop,
  Grid,
  Paper,
  FormLabel,
  styled,
  Typography,
} from "@mui/material";
import ActionButton from "../../components/ActionButton";
import StatusChipButton from "../../components/StatusChip";
import { RequestPool, RequestPoolStatusLabel } from "../../types";
import Moment from "react-moment";

interface RequestDetailProps {
  open: boolean;
  requestDetail: RequestPool;
  status: string;
  onCancel: () => void;
}

const RequestDetailContainer = styled(Paper)`
  width: auto;
  height: auto;
  border-radius: 15px;
  padding: 8px 20px 20px 20px;
`;
const Heading = styled(Typography)`
  margin-bottom: 8px;
  text-align: center;
`;

const Label = styled(FormLabel)`
  font-weight: 700;
  font-size: 19px;
  color: #000000;
  width: 30%;
  text-align: left;
`;

function RequestDetail({
  open,
  requestDetail,
  status,
  onCancel,
}: RequestDetailProps) {
  return (
    <Backdrop
      sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
      open={open}
    >
      <Grid container justifyContent="center">
        <Grid item xs={7}>
          <RequestDetailContainer>
            <Heading variant="h6" color="secondary">
              Request Details
              <StatusChipButton
                statusText={RequestPoolStatusLabel.get(
                  requestDetail?.isCompleted
                )}
                status={status}
                height={24}
                fontSize={11}
                marginLeft={10}
              />
            </Heading>

            <div
              style={{
                backgroundColor: "#FFF",
                padding: "40px 40px 16px 40px",
                borderRadius: "16px",
              }}
            >
              <div className="detailsWrapper">
                <Label>Request No</Label><span style={{width: '2%'}}>:</span> <span style={{width: '78%', textAlign: 'left'}}>{requestDetail?.trackingId}</span>
              </div>
              <div className="detailsWrapper">
                <Label>Assignee</Label><span style={{width: '2%'}}>:</span> <span style={{width: '78%', textAlign: 'left'}}>{requestDetail?.createdBy}</span>
              </div>
              <div className="detailsWrapper">
                <Label>Payload</Label><span style={{width: '2%'}}>:</span> <span style={{width: '78%', textAlign: 'left'}}>{requestDetail?.hapi}</span>
              </div>
              <div className="detailsWrapper">
                <Label>Date</Label><span style={{width: '2%'}}>:</span>
                <span style={{width: '78%', textAlign: 'left'}}><Moment format="MMM DD, YYYY">{requestDetail.createdOn}</Moment></span>
              </div>
              <div className="detailsWrapper">
                <Label>Time</Label><span style={{width: '2%'}}>:</span>
                <span style={{width: '78%', textAlign: 'left'}}><Moment format="hh:mm">{requestDetail.createdOn}</Moment></span>
              </div>
              <div className="detailsWrapper">
                <Label>Details</Label><span style={{width: '2%'}}>:</span> <span style={{width: '100%', height:"300px", overflowY:"scroll",textAlign: 'left', overflowWrap: 'anywhere'}}>{requestDetail?.messageDetail}</span>
              </div>

              <ActionButton
                text={"ok"}
                width={96}
                height={60}
                radius={15}
                fontSize={19}
                fontWeight={800}
                color={"#70CCF2"}
                action={() => onCancel()}
              />
            </div>
          </RequestDetailContainer>
        </Grid>
      </Grid>
    </Backdrop>
  );
}

export default RequestDetail;
