import * as React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import RequestPoolListToolbar from "./RequestPoolListToolbar";
import RequestPoolListHead from "./RequestPoolListHead";
import {
  RequestPool,
  Order,
  RequestPoolStatus,
  RequestPoolStatusLabel,
  NodeSetupStatusLabel,
} from "../../types";
import Paper from "@mui/material/Paper";
import RequestPoolIcon from "../../assets/images/image1.png";
import StatusChipButton from "../../components/StatusChip";
import { Grid } from "@mui/material";
import { useEffect, useState, useContext } from "react";
import { createRequest } from "../../services/ApiServices";
import Moment from "react-moment";
import RequestDetail from "./RequestDetails";
import { ProgressContext } from "../../context/ProgressContext";
import { stableSort, getComparator } from "../../utils";

const ROW_HEIGHT = 53;

const RequestPoolListTable = styled(Paper)`
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #dfe0eb;
  padding: 15px 0;
  margin-top: 35px;
`;

function RequestPoolList() {
  const [order, setOrder] = useState<Order>("desc");
  const { setProgressData } = useContext(ProgressContext);
  const [filteredRows, setFilteredRows] = useState<any[]>([]);
  const [rows, setRows] = useState<RequestPool[]>([]);
  const [orderBy, setOrderBy] = useState<keyof RequestPool>("lastUpdatedOn");
  const [selected, setSelected] = useState<RequestPool>();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [requestDetailsView, setRequestDetailsView] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [requestCount, setRequestCount] = useState(0);
  const [header,setHeader] = useState("TrackingId");
   
  useEffect(() => {
    getRequestCounts();
    getRequestPool(page);
  }, []);

  const filterQuery: any = {};
  if (searchTerm) {
    filterQuery[header] = [searchTerm];
  }
  const getRequestPool = (newPage: number, rowsPage?: number) => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "requestPool",
      method: "create",
      body: {
        pageSize: rowsPage ? rowsPage : rowsPerPage,
        pageIndex: newPage + 1,
        filterQuery:filterQuery
      },
    })
      ?.then(async (res) => { 
        setFilteredRows(res?.data)
        setRows(res?.data);
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };

  const getRequestCounts = () => {
    createRequest({
      api: "requestPoolCount",
      method: "fetch_all",
    })
      ?.then(async (res) => {
        setRequestCount(res.data);
      })
      ?.catch((err) => {});
  };

  const handleClick = (
    event: React.MouseEvent<unknown>,
    selectedRequest: RequestPool
  ) => {
    setSelected(selectedRequest);
    setRequestDetailsView(true);
  };

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof RequestPool
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleRequestDetailsClose = () => {
    setRequestDetailsView(false);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
    getRequestPool(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
    getRequestPool(0, parseInt(event.target.value, 10));
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;


    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const inputValue = e.target.value;
      setSearchTerm(inputValue);
      if (inputValue === "") {
        setRows(rows);
        setFilteredRows(rows)
      }
    };

    const handleFilterData = () => { 
      setRows(filteredRows);
      getRequestPool(page)
    }

  return (
    <>
      {selected && (
        <RequestDetail
          status={RequestPoolStatus[selected?.isCompleted]}
          requestDetail={selected}
          open={requestDetailsView}
          onCancel={() => handleRequestDetailsClose()}
        />
      )}
      <Box sx={{ width: "100%" }} color="secondary">
        <RequestPoolListTable sx={{ width: "100%", mb: 2 }} color="secondary">
          <RequestPoolListToolbar requestCount={requestCount} searchTerm={searchTerm}
          handleSearchChange={handleSearchChange} handleFilterData={handleFilterData}
          header={header} setHeader={setHeader}/>
          
          <TableContainer color="secondary">
            <Table
              sx={{ minWidth: 750 }}
              aria-labelledby="tableTitle"
              size={"medium"}
            >
              <RequestPoolListHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
              />
              <TableBody>
                {
                  rows &&
                  rows.length > 0 &&
                  stableSort<any>(rows, getComparator(order, orderBy))
                  .map((row: RequestPool, index: number) => {
                      const labelId = `request-setup-${row.trackingId}`;
                      return (
                        <TableRow
                          hover
                          key={row.trackingId}
                          onClick={(event) => handleClick(event, row)}
                        >
                          <TableCell>
                            <img src={RequestPoolIcon} alt="RequestPoolIcon" />
                          </TableCell>
                          <TableCell
                            component="th"
                            id={labelId}
                            scope="row"
                            padding="none"
                          >
                            <p>{row.trackingId}</p>
                          </TableCell>
                          <TableCell align="left">{row.hapi}</TableCell>
                          <TableCell align="left">{row.node}</TableCell>
                          <TableCell align="left">
                            <Grid container direction="column">
                              <Moment format="MMM DD, YYYY">
                                {row.createdOn}
                              </Moment>
                              <Grid
                                item
                                sx={{
                                  fontSize: "12px",
                                  color: "#C5C7CD",
                                  paddingTop: "5px",
                                }}
                              >
                                <Moment format="hh:mm">{row.createdOn}</Moment>
                              </Grid>
                            </Grid>
                          </TableCell>
                          <TableCell align="left">
                            <Grid container direction="column">
                              <Moment format="MMM DD, YYYY">
                                {row.lastUpdatedOn}
                              </Moment>
                              <Grid
                                item
                                sx={{
                                  fontSize: "12px",
                                  color: "#C5C7CD",
                                  paddingTop: "5px",
                                }}
                              >
                                <Moment format="hh:mm">
                                  {row.lastUpdatedOn}
                                </Moment>
                              </Grid>
                            </Grid>
                          </TableCell>
                          <TableCell align="left">
                            <StatusChipButton
                              statusText={RequestPoolStatusLabel.get(
                                row.isCompleted
                              )}
                              status={RequestPoolStatus[row.isCompleted]}
                              height={24}
                              width={100}
                            />
                          </TableCell>
                          <TableCell align="left">
                            {/* {row.messageDetail.length > 15 ? row.messageDetail.slice(0,50) : "Empty"} */}
                            <button style={{ width: "120px", padding: "8px", outline: "none", border: "none", backgroundColor: "#D9D9D966", fontSize: "16px", fontWeight: "700", cursor: "pointer", borderRadius: "10px" }}>See Details</button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                {emptyRows > 0 && rows.length === 0 && (
                  <TableRow
                    style={{
                      height: ROW_HEIGHT * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={requestCount}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </RequestPoolListTable>
      </Box>
    </>
  );
}

export default RequestPoolList;
