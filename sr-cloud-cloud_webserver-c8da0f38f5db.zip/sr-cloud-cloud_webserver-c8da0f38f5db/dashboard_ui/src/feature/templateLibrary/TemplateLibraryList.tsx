import React, {
  useEffect,
  useState,
  MouseEvent,
  ChangeEvent,
  useContext,
} from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import TemplateLibraryListToolbar from "./TemplateLibraryListToolbar";
import TemplateLibraryListHead from "./TemplateLibraryListHead";
import { Order, TemplateLibrary } from "../../types";
import Paper from "@mui/material/Paper";
import { stableSort, getComparator } from "../../utils";
import {
  Collapse,
  Grid,
  IconButton,
  NativeSelect,
  TableHead,
  Typography,
} from "@mui/material";
import Moment from "react-moment";
import ActionButton from "../../components/ActionButton";
import { createRequest } from "../../services/ApiServices";
import { ProgressContext } from "../../context/ProgressContext";
import { ApiContext } from "../../context/ApiContext";
import { Link } from "react-router-dom";
import back from "../../../src/assets/images/back.png"
const ROW_HEIGHT = 53;

const DUTListTable = styled(Paper)`
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #dfe0eb;
  padding: 15px 0;
  margin-top: 35px;
`;

interface ChangeStatus {
  initiateChange?: boolean;
  nodeId?: number;
  onCancel?: (id?: number) => void;
}

function TemplateLibraryList({
  initiateChange = false,
  nodeId,
  onCancel,
}: ChangeStatus) {
  const [order, setOrder] = useState<Order>("asc");
  const [orderBy, setOrderBy] = useState<keyof TemplateLibrary>("name");
  const [selected, setSelected] = useState<readonly string[]>([]);
  const [page, setPage] = useState(0);
  const [rows, setRows] = useState<TemplateLibrary[]>([]);
  const [filterRows, setFilteredRows] = useState(rows);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const { setProgressData } = useContext(ProgressContext);
  const { setApiData } = useContext(ApiContext);

  useEffect(() => {
    getTemplateLibrary();
  }, []);

  const getTemplateLibrary = () => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "template",
      method: "fetch_all",
    })
      ?.then(async (res) => {
        setRows(res.data);
        setFilteredRows(res.data);
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };

  const handleRequestSort = (
    event: MouseEvent<unknown>,
    property: keyof TemplateLibrary
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      const newSelected = rows.map((n) => n.name);
      setSelected(newSelected);
      return;
    }
    setSelected([]);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const applyTemplate = (templateName: string) => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "applyTemplate",
      method: "node_action",
      id: nodeId?.toString(),
      params: {
        templateName: templateName,
      },
    })
      ?.then(async (res) => {
        setProgressData({
          isLoading: false,
        });
        setApiData({
          showApiStatus: true,
          message: "Applied Succesfully",
          backgroundColor: "#37B2E4",
        });
        onCancel && onCancel(nodeId);
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: true,
        });
        setApiData({
          showApiStatus: true,
          message: "Error in applying template",
          backgroundColor: "#A84849",
        });
      });
  };

  const [searchTerm, setSearchTerm] = useState("")

  const handleSearchChange = (e: any) => {
    const inputValue = e.target.value
    setSearchTerm(e.target.value)
    
    if(inputValue===""){
      setRows(filterRows)
    }
    
  };

  const handleFilterData = () => {
    const filteredData = rows.filter((item: any) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setRows(filteredData);
  };

  function Row(props: { row: any }) {
    const { row } = props;
    const [open, setOpen] = React.useState(false);
  
    return (
      <React.Fragment>
        <TableRow hover>
          <TableCell>
            <IconButton
              aria-label="expand row"
              size="small"
              onClick={() => setOpen(!open)}
            >
              {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
            </IconButton>
          </TableCell>
          <TableCell>
            <Grid container direction="column">
              <Grid item>{row.name}</Grid>
              <Grid
                item
                sx={{
                  fontSize: "12px",
                  color: "#C5C7CD",
                  paddingTop: "5px",
                }}
              >
                Updated{" "}
                <Moment fromNow ago>
                  {row.updatedDate}
                </Moment>{" "}
                ago
              </Grid>
            </Grid>
          </TableCell>
          <TableCell align="left">
            <Moment format="MMM DD, YYYY">{row.updatedDate}</Moment>
          </TableCell>
          <TableCell align="left">{row.createdBy}</TableCell>
          {initiateChange && (
            <TableCell align="left">
              <ActionButton
                text={"Apply"}
                width={90}
                height={24}
                color={"#29CC97"}
                action={() => applyTemplate(row?.name)}
              />
            </TableCell>
          )}
        </TableRow>
        <TableRow>
          <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
            <Collapse in={open} timeout="auto" unmountOnExit>
              <Box
                sx={{ margin: 1 }}
                style={{
                  boxShadow: "0px 7px 18px 0px rgba(0,0,0,0.1)",
                  padding: "5px",
                }}
              >
                <Typography variant="h6" gutterBottom component="div">
                  DUTs
                </Typography>
                <Table size="small" aria-label="purchases">
                  <TableHead>
                    <TableRow>
                      <TableCell
                        style={{ borderBottom: "1px solid rgba(0, 0, 0, .1)" }}
                      >
                        Name
                      </TableCell>
                      <TableCell
                        style={{ borderBottom: "1px solid rgba(0, 0, 0, .1)" }}
                      >
                        DUT
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {row.dutDetail.map(
                      (dutDetailRow: { dut: string; name: string }) => (
                        <TableRow key={dutDetailRow.dut}>
                          <TableCell
                            component="th"
                            scope="row"
                            style={{
                              borderBottom: "1px solid rgba(0, 0, 0, .1)",
                            }}
                          >
                            {dutDetailRow.dut}
                          </TableCell>
                          <TableCell
                            style={{
                              borderBottom: "1px solid rgba(0, 0, 0, .1)",
                            }}
                          >
                            {dutDetailRow.name}
                          </TableCell>
                        </TableRow>
                      )
                    )}
                  </TableBody>
                </Table>
              </Box>
            </Collapse>
          </TableCell>
        </TableRow>
      </React.Fragment>
    );
  }

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  return (
    <>
      <Box sx={{ width: "100%" }} color="secondary">
      <Link to={"/nodesetup"}>
        <div style={{marginTop:"10px",display:"flex",alignItems:"center",gap:"5px",cursor:"pointer",color:"#000",textDecoration:"none"}}>
          <img src={back} alt="back" width={20} height={20}/>
          <h4 style={{textDecoration:"none"}}>Node Setup</h4>
        </div>
        </Link>
        <DUTListTable sx={{ width: "100%", mb: 2 }} color="secondary">
          <TemplateLibraryListToolbar numSelected={selected.length} handleSearchChange={handleSearchChange} searchTerm={searchTerm} handleFilterData={handleFilterData} />
          <TableContainer color="secondary">
            <Table
              sx={{ minWidth: 750, borderColor: "#DFE0EB" }}
              aria-labelledby="tableTitle"
              size={"medium"}
            >
              <TemplateLibraryListHead
                numSelected={selected.length}
                order={order}
                orderBy={orderBy}
                onSelectAllClick={handleSelectAllClick}
                onRequestSort={handleRequestSort}
                rowCount={rows.length}
                initiateChange={initiateChange}
              />
              <TableBody>
                {stableSort(rows, getComparator(order, orderBy))
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((row, index) => {
                    return <Row key={row.name} row={row} />;
                  })}
                {emptyRows > 0 && (
                  <TableRow
                    style={{
                      height: ROW_HEIGHT * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <Grid container alignItems="center" justifyContent="flex-end">
            {initiateChange && (
              <Grid item>
                <ActionButton
                  text={"Cancel"}
                  width={90}
                  height={36}
                  fontSize={14}
                  fontWeight={800}
                  color={"#E86B6C"}
                  action={onCancel}
                />
              </Grid>
            )}
            <Grid item xs={5}>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={rows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Grid>
          </Grid>
        </DUTListTable>
      </Box>
    </>
  );
}

export default TemplateLibraryList;
