import styled from "@emotion/styled";
import { Typography, Toolbar, alpha } from "@mui/material";
import ActionButton from "../../components/ActionButton";
import SearchBar from "../../components/SearchBar";

interface TemplateLibraryListToolbarProps {
    numSelected: number;
    handleSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
    searchTerm:string;
    handleFilterData:()=>void
  }
  
  const NodeListHeader = styled(Typography)`
        text-align: left;
        color: #252733;
      `
    ;
  
  function TemplateLibraryListToolbar(props: TemplateLibraryListToolbarProps) {
    const { numSelected,handleSearchChange,searchTerm,handleFilterData} = props;
  
    return (
      <Toolbar
        sx={{
          pl: { sm: 2 },
          pr: { xs: 1, sm: 1 },
          ...(numSelected > 0 && {
            bgcolor: (theme) =>
              alpha(
                theme.palette.primary.main,
                theme.palette.action.activatedOpacity
              ),
          }),
        }}
      >
        <NodeListHeader
          sx={{ flex: "1 1 100%" }}
          variant="h6"
          id="tableTitle"
        >
          Template Library
        </NodeListHeader>
        <SearchBar handleSearchChange={handleSearchChange} searchTerm={searchTerm}/>
        <ActionButton text={"Sync"} width={76} height={24} handleFilterData={handleFilterData}/>
      </Toolbar>
    );
  }

  export default TemplateLibraryListToolbar;