import * as React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import NodeSetupListToolbar from "./NodeSetupListToolbar";
import NodeSetupListHead from "./NodeSetupListHead";
import {
  NodeData,
  Order,
  NodeSetupStatus,
  NodeSetupStatusLabel,
} from "../../types";
import Paper from "@mui/material/Paper";
import { stableSort, getComparator } from "../../utils";
import nodeSetupIcon from "../../assets/images/nodeSetupIcon.png";
import StatusChipButton from "../../components/StatusChip";
import MoreVert from "../../assets/icons/MoreVert";
import {
  Backdrop,
  Divider,
  Grid,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import NodeVerficationStatus from "../../components/NodeVerificationStatus";
import TemplateLibraryList from "../templateLibrary/TemplateLibraryList";
import NodeChange from "../nodeChanges/NodeChange";
import NodeDetails from "../nodeChanges/NodeDetails";
import { useEffect, useState, useContext } from "react";
import { createRequest } from "../../services/ApiServices";
import Moment from "react-moment";
import { ProgressContext } from "../../context/ProgressContext";
import { ApiContext } from "../../context/ApiContext";
import { useNavigate } from "react-router-dom";
import Verification from "./Verification";


const optionsUnverfied = [
  { id: 0, name: "Verify Node" },
  { id: 1, name: "Details" },
  { id: 2, name: "Initiate DUT Change" },
  { id: 3, name: "Manual Verification" },
];

const options = [
  { id: 0, name: "Verify Node" },
  { id: 1, name: "Details" },
  { id: 2, name: "Initiate DUT Change" },
  { id: 3, name: "Manual Verification" },
];

const ITEM_HEIGHT = 40;
const ROW_HEIGHT = 53;

const NodeListTable = styled(Paper)`
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #dfe0eb;
  padding: 15px 0;
  margin-top: 35px;
`;

const ItemDivider = styled(Divider)`
  margin: 0 !important;
  border-color: #fff;
  border-width: 1px;
`;

function NodeSetupList() {
  const [order, setOrder] = useState<Order>("asc");
  const [filteredRows, setFilteredRows] = useState<any[]>([])
  const [rows, setRows] = useState<NodeData[]>(filteredRows);
  const [orderBy, setOrderBy] = useState<keyof NodeData>("nodeId");
  const [selected, setSelected] = useState<NodeData>();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [nodeVerification, setNodeVerification] = useState(false);
  const [nodeDetailsView, setNodeDetailsView] = useState(false);
  const [initiateDUTChange, setInitiateDUTChange] = useState(false);
  const [addEditNode, setAddEditNode] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const { setProgressData } = useContext(ProgressContext);
  const { setApiData } = useContext(ApiContext);
  const [searchTerm, setSearchTerm] = useState('')


  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const navigate = useNavigate();
  useEffect(() => {
    getNodes();
  }, []);

  const getNodes = () => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "node",
      method: "fetch_all",
    })
      ?.then(async (res) => {
        setRows(res?.data);
        setFilteredRows(res?.data)
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>, selectedNode: NodeData) => {
    setSelected(selectedNode);
    setAnchorEl(event.currentTarget);
  };
  const handleMenu = (optionId: number) => {
    setAnchorEl(null);
    if (optionId === 0) {
      handleNodeVerificationOpen();
    } else if (optionId === 1) {
      handleNodeDetailsOpen();
    } else if (optionId === 2) {
      handleInitiateDUTChangeOpen();
    } else if (optionId === 3) {
      const ipAddress = selected?.ipAddress || "";
      handleManualVerification(ipAddress);
    }
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleRequestSort = (
    event: React.MouseEvent<unknown>,
    property: keyof NodeData
  ) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleNodeVerificationOpen = () => {
    setNodeVerification(true);
    let nodeId = selected?.nodeId;
    createRequest({
      api: "verifyTemplate",
      method: "node_action",
      id: nodeId?.toString(),
    })
      ?.then(async (res) => {
        setProgressData({
          isLoading: false,
        });
        getUpdatedNode(nodeId);
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
        setApiData({
          showApiStatus: true,
          message: "Could not verify template",
          backgroundColor: "#A84849",
        });
      });
  };

  const getUpdatedNode = (nodeId?: number) => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "node",
      method: "fetch_by_id",
      id: nodeId?.toString(),
    })
      ?.then(async (res) => {
        const index = rows.findIndex((node) => node.nodeId === nodeId);
        if (index > -1) {
          const nodeRows = rows;
          nodeRows[index] = res.data;
          setRows([...nodeRows]);
        }
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };

  const handleNodeVerificationClose = () => {
    setNodeVerification(false);
  };

  const handleNodeDetailsOpen = () => {
    setNodeDetailsView(true);
  };

  const handleNodeDetailsClose = (update: Boolean, nodeId?: number) => {
    setNodeDetailsView(false);
    if (update) {
      if (nodeId) {
        getUpdatedNode(nodeId);
      } else {
        getNodes();
      }
    }
  };

  const handleInitiateDUTChangeOpen = () => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "dutChange",
      method: "node_action",
      id: selected?.nodeId?.toString(),
    })
      ?.then(async (res) => {
        setProgressData({
          isLoading: false,
        });
        setInitiateDUTChange(true);
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
        setApiData({
          showApiStatus: true,
          message: "Could not initiate DUT Change",
          backgroundColor: "#A84849",
        });
      });
  };

  const handleManualVerification = (ipAddress: string) => {
    console.log("ipadresss", ipAddress);
    window.open(`http://${ipAddress}`, '__blank');
  }

  const handleInitiateDUTChangeClose = (nodeId?: number) => {
    if (nodeId) {
      getUpdatedNode(nodeId);
    }
    setInitiateDUTChange(false);
  };

  const addNode = () => {
    setAddEditNode(true);
    setIsEdit(false);
  };

  const editNode = () => {
    setNodeDetailsView(false);
    setAddEditNode(true);
    setIsEdit(true);
  };

  const cancelAddNode = () => {
    setAddEditNode(false);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // Avoid a layout jump when reaching the last page with empty rows.
  const emptyRows =
    page > 0 ? Math.max(0, (1 + page) * rowsPerPage - rows.length) : 0;

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value;
    setSearchTerm(inputValue);

    if (inputValue === "") {
      setRows(filteredRows)
    }
  };

  const handleFilterData = () => {
    const searchTermLower = searchTerm.toLowerCase();
    const filteredData = filteredRows.filter((item: any) => {
      const statusLabel = NodeSetupStatusLabel.get(item.statusId)?.toLowerCase();
      return (
        item?.nodeIdentifier.toLowerCase().includes(searchTerm?.toLowerCase()) ||
        item?.templateName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item?.serialNumber.includes(searchTerm) ||
        (statusLabel && statusLabel.includes(searchTermLower))
      )
    }

    );
    setRows(filteredData);
  };



  return (
    <>
      {nodeVerification && (
        <NodeVerficationStatus
          open={nodeVerification}
          title="Verification Ongoing..."
          content={"Node Status will be \n updated after completing"}
          handleClose={handleNodeVerificationClose}
        />
      )}
      {nodeDetailsView && selected && (
        <NodeDetails
          name={selected?.name}
          id={selected.nodeId}
          status={NodeSetupStatus[selected?.statusId]}
          open={nodeDetailsView}
          editNode={editNode}
          onCancel={(update: Boolean, nodeId?: number) =>
            handleNodeDetailsClose(update, nodeId)
          }
        />
      )}
      {initiateDUTChange && (
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={initiateDUTChange}
        >
          <Grid container justifyContent="center">
            <Grid item xs={10}>
              <TemplateLibraryList
                initiateChange={true}
                nodeId={selected?.nodeId}
                onCancel={(event: any, nodeId?: number) => handleInitiateDUTChangeClose(nodeId)}
              />
            </Grid>
          </Grid>
        </Backdrop>
      )}
      {addEditNode && (
        <NodeChange
          open={addEditNode}
          id={selected?.nodeId}
          isEdit={isEdit}
          updateNodeList={() =>
            isEdit ? getUpdatedNode(selected?.nodeId) : getNodes()
          }
          onCancel={cancelAddNode}
          setAddEditNode={setAddEditNode}
        />
      )}
      <Box sx={{ width: "100%" }} color="secondary">
        <NodeListTable sx={{ width: "100%", mb: 2 }} color="secondary">
          <NodeSetupListToolbar action={addNode} searchTerm={searchTerm} handleSearchChange={handleSearchChange}
            handleFilterData={handleFilterData} />
          <TableContainer color="secondary">
            <Table
              sx={{ minWidth: 750 }}
              aria-labelledby="tableTitle"
              size={"medium"}
            >
              <NodeSetupListHead
                order={order}
                orderBy={orderBy}
                onRequestSort={handleRequestSort}
                rowCount={rows.length}
              />
              <TableBody>
                {rows &&
                  rows.length > 0 &&
                  stableSort<any>(rows, getComparator(order, orderBy))
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((row: NodeData, index: number) => {
                      const labelId = `node-setup-${index}`;

                      return (
                        <TableRow hover key={row.nodeId}>
                          <TableCell>
                            <img src={nodeSetupIcon} alt="nodeSetupIcon" />
                          </TableCell>
                          <TableCell
                            component="th"
                            id={labelId}
                            scope="row"
                            padding="none"
                          >
                            <Grid container direction="column">
                              <Grid item>{row.nodeIdentifier}</Grid>

                              <Grid
                                item
                                sx={{
                                  fontSize: "12px",
                                  color: "#C5C7CD",
                                  paddingTop: "5px",
                                }}
                              >
                                Updated{" "}
                                <Moment fromNow ago>
                                  {row.lastUpdatedOn}
                                </Moment>{" "}
                                ago
                              </Grid>
                            </Grid>
                          </TableCell>
                          {/* <TableCell align="left">
                          {row.currentTemplate}
                        </TableCell>
                        <TableCell align="left">
                          {row?.templateUpdateDate?.getDate()}
                        </TableCell> */}

                          <TableCell align="left">{row.templateName}</TableCell>
                          {/* <TableCell align="left">{row.dut1}</TableCell>
                        <TableCell align="left">{row.dut2}</TableCell>
                        <TableCell align="left">{row.dut3}</TableCell>
                        <TableCell align="left">{row.dut4}</TableCell> */}
                          <TableCell align="left">
                            <Moment format="MMM DD, YYYY">
                              {row.lastUpdatedOn}
                            </Moment>
                          </TableCell>
                          <TableCell align="left">
                            <StatusChipButton
                              statusText={NodeSetupStatusLabel.get(
                                row.statusId
                              )}
                              status={NodeSetupStatus[row.statusId]}
                              height={40}
                              width={100}
                            />
                          </TableCell>
                          <TableCell align="left">
                            {" "}
                            <div style={{marginLeft:"130px"}}>
                              <IconButton
                                aria-label="more"
                                id="long-button"
                                aria-controls={open ? "long-menu" : undefined}
                                aria-expanded={open ? "true" : undefined}
                                aria-haspopup="true"
                                onClick={(event) => handleMenuClick(event, row)}
                              >
                                <MoreVert />
                              </IconButton>
                              <Menu
                                id="long-menu"
                                MenuListProps={{
                                  "aria-labelledby": "long-button",
                                  style: {
                                    padding: 0,
                                  },
                                }}
                                anchorEl={anchorEl}
                                open={open}
                                onClose={handleClose}
                                PaperProps={{
                                  style: {
                                    maxHeight: ITEM_HEIGHT * 4.5,
                                    width: "20ch",
                                    color: "#fff",
                                    borderRadius: 0,
                                    boxShadow: "none",
                                    textTransform: "uppercase",
                                    
                                  },
                                }}
                              >
                                {(selected?.statusId === 4
                                  ? optionsUnverfied
                                  : options
                                ).map((option) => [
                                  <MenuItem
                                    key={option.id}
                                    onClick={() => handleMenu(option.id)}
                                    sx={{
                                      backgroundColor: "#363740",
                                      fontSize: "14px",
                                      fontWeight: 700,
                                      "&:hover": {
                                        backgroundColor: "#000",
                                        color: "#fff",

                                      },
                                    }}
                                  >
                                    {option.name}
                                  </MenuItem>,
                                  <ItemDivider />,
                                ])}
                              </Menu>

                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                {emptyRows > 0 && (
                  <TableRow
                    style={{
                      height: ROW_HEIGHT * emptyRows,
                    }}
                  >
                    <TableCell colSpan={6} />
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            count={rows.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </NodeListTable>
      </Box>

    </>
  );
}

export default NodeSetupList;
