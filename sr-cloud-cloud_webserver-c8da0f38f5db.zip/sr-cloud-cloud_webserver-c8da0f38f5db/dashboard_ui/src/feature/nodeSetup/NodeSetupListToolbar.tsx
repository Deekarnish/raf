import styled from "@emotion/styled";
import { Typography, Toolbar, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";
import ActionButton from "../../components/ActionButton";
import SearchBar from "../../components/SearchBar";

interface NodeSetupListToolbarProps {
  action: () => void;
}

const NodeListHeader = styled(Typography)`
  text-align: left;
  color: #252733;
`;
function NodeSetupListToolbar({action,searchTerm,handleFilterData,handleSearchChange}:any) {
  const navigate = useNavigate();

  return (
    <Toolbar
    >
      <NodeListHeader sx={{ flex: "1 1 30%",marginRight:"50px" }} variant="h6" id="tableTitle">
        Node Setups
      </NodeListHeader>
      <Box 
      sx={{display:"flex",alignItems:"center",justifyContent:"center"}}>
      <SearchBar searchTerm={searchTerm} handleSearchChange={handleSearchChange}/>
      <ActionButton text={"Sync"} width={26} height={24} handleFilterData={handleFilterData}/>
      <ActionButton text={"Add Node"} action={action} width={80} height={40} />
      <ActionButton
      width={100} height={50}
        text={"View dut master database"}
        action={() =>
          navigate("/nodesetup/DUTMasterLibrary", {
            state: { title: "DUT Master Library" },
          })
        }
       
      />
      <ActionButton text={"View template library"} 
      width={100} height={50}
      action={() =>
          navigate("/nodesetup/templateLibrary", {
            state: { title: "Template Library" },
          })
          
        } /> 
    </Box>
    </Toolbar>
  );
}

export default NodeSetupListToolbar;
