import React, { useContext, useEffect, useState } from "react";
import {
  Backdrop,
  Grid,
  Paper,
  FormLabel,
  styled,
  Typography,
  IconButton,
  Menu,
  MenuItem,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
} from "@mui/material";
import ActionButton from "../../components/ActionButton";
import StatusChipButton from "../../components/StatusChip";
import { NodeData, NodeSetupStatusLabel } from "../../types";
import { createRequest } from "../../services/ApiServices";
import { ApiContext } from "../../context/ApiContext";
import axios from "axios";
import Urls from "../../services/Urls";
import { ProgressContext } from "../../context/ProgressContext";
import Moment from "react-moment";

interface NodeDetailsProps {
  open: boolean;
  name?: string;
  id: number;
  status: string;
  editNode: () => void;
  onCancel: (update: Boolean, id?: number) => void;
}

interface adminOption {
  id: number;
  name: string;
  status: number | null;
}

const ITEM_HEIGHT = 40;

const options: adminOption[] = [
  { id: 0, name: "Edit Node", status: null },
  { id: 1, name: "Initiate Maintenance", status: 10 },
  { id: 2, name: "Activate Node", status: 1 },
  { id: 3, name: "Move to On Hold", status: 12 },
  { id: 4, name: "Firmware Update", status: null },
  { id: 5, name: "Delete Node", status: null },
];

const NodeDetailsContainer = styled(Paper)`
  width: auto;
  height: auto;
  border-radius: 15px;
  padding: 8px 20px 20px 20px;
`;
const Heading = styled(Typography)`
  margin-bottom: 8px;
  text-align: left;
`;
const NodeSelected = styled(Typography)`
  color: #fcfcff;
  font-size: 24px;
  font-weight: 700;
  width: 55%;
  text-align: right;
  padding-right: 15px;
`;
const Label = styled(FormLabel)`
  font-weight: 700;
  font-size: 19px;
  color: #000000;
  width: 30%;
  text-align: left;
`;
const MenuItemAdmin = styled(MenuItem)`
  &:hover {
       background-color: white !important;
     }
`;



function NodeDetails({
  open,
  name,
  id,
  status,
  editNode,
  onCancel,
}: NodeDetailsProps) {
  const { setApiData } = useContext(ApiContext);
  const { setProgressData } = useContext(ProgressContext);
  const [nodeDetails, setNodeDetails] = useState<NodeData>();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const openAdminView = Boolean(anchorEl);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  useEffect(() => {
    getNodeDetails();
  }, []);

  const getNodeDetails = () => {
    createRequest({
      api: "node",
      method: "fetch_by_id",
      id: id.toString(),
    })
      ?.then(async (res) => {
        setNodeDetails(res.data);
      })
      ?.catch((err) => { });
  };

  const deleteNode = () => {
    createRequest({
      api: "node",
      method: "delete",
      id: id.toString(),
    })
      ?.then(async (res) => {
        onCancel(true);
        setApiData({
          showApiStatus: true,
          message: "Successfully Deleted",
          backgroundColor: "#37B2E4",
        });
      })
      ?.catch((err) => { });
  };

  const updateNodeStatus = (status: number | null) => {
    createRequest({
      api: "node",
      method: "patch",
      id: id.toString(),
      params: {
        statusId: status,
      },
    })
      ?.then(async (res) => {
        onCancel(true, id);
        setApiData({
          showApiStatus: true,
          message: "Successfully Updated",
          backgroundColor: "#37B2E4",
        });
      })
      ?.catch((err) => { });
  };

  const handleFileUpload = (event: any) => {
    const file = event.target.files[0];

    // create a new FormData object and append the file to it
    const formData = new FormData();
    formData.append("File", file);
    formData.append("FileName", file.name);
    setProgressData({
      isLoading: true,
    });
    onCancel(false);
    axios
      .post(Urls.BaseUrl + "node/" + id + Urls.firmwareUpdate, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((response) => {
        setProgressData({
          isLoading: false,
        });
        setApiData({
          showApiStatus: true,
          message: "Successfully Updated",
          backgroundColor: "#37B2E4",
        });
      })
      .catch((error) => {
        console.log(error);
        setProgressData({
          isLoading: false,
        });
        setApiData({
          showApiStatus: true,
          message: "Firmware not updated",
          backgroundColor: "#A84849",
        });
      });
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleMenu = (
    event: React.MouseEvent<HTMLLIElement, MouseEvent>,
    option: adminOption
  ) => {
    switch (option.id) {
      case 0:
        editNode();
        break;
      case 1:
      case 2:
      case 3:
        updateNodeStatus(option.status);
        break;
      case 4:
        break;
      case 5:
        setDeleteDialogOpen(true); // Open delete confirmation dialog
        break;
      default:
        break;
    }
    setAnchorEl(null);
  };

  const handleDeleteConfirmation = () => {
    deleteNode();
    setDeleteDialogOpen(false);
  };

  const handleDeleteCancel = () => {
    setDeleteDialogOpen(false);
  };
  return (
    <Backdrop
      sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
      open={open}
    >
      <Grid container justifyContent="center">
        <Grid item xs={7}>
          <NodeDetailsContainer>
            <Heading variant="h6" color="secondary">
              Node Detail
            </Heading>
            <div
              style={{
                backgroundColor: "#FFF",
                padding: "40px 40px 16px 40px",
                borderRadius: "16px",
              }}
            >
              <div className="detailNameWrapper">
                <NodeSelected variant="h3" color="secondary">
                  {'Node ' + nodeDetails?.nodeIdentifier}
                </NodeSelected>
                {nodeDetails && nodeDetails?.statusId && (
                  <StatusChipButton
                    statusText={NodeSetupStatusLabel.get(nodeDetails?.statusId)}
                    status={status}
                    height={32}
                    fontSize={18}
                  />
                )}
              </div>

              <div className="detailsWrapper" style={{ display:"flex",justifyContent: 'space-between',marginTop:"50px"}}>
                <div style={{ display:"flex",flexDirection:"column",alignItems:"flex-start" }}>
                <div className="detailsWrapper">
                  <div >Robot Serial Number</div>&nbsp;: {nodeDetails?.serialNumber}
                </div>

                <div className="detailsWrapper">
                  <div>Template</div>&nbsp;: {nodeDetails?.templateName}
                </div>
                {/* <div className="detailsWrapper">
                <Label>Template Date</Label>:
                </div> */}
                <div className="detailsWrapper">
                  <div>Template Uploaded by</div>&nbsp;:
                </div>
                <div className="detailsWrapper">
                  <div>Firmware version</div>&nbsp;: {nodeDetails?.firmwareVersion}
                </div>
                <div className="detailsWrapper">
                  <div>Firmware Update Date</div>&nbsp;: <span style={{ marginLeft: '5px' }}><Moment format="MMM DD, YYYY">{nodeDetails?.lastUpdatedOn}</Moment></span>
                </div>
                {/* <div className="detailsWrapper">
                <Label>Messages / Alerts</Label>: {nodeDetails?.comment}
                </div> */}
                <div className="detailsWrapper">
                  <div>Total Uptime</div>&nbsp;: {nodeDetails?.totalUptime}
                </div>
                <div className="detailsWrapper">
                  <div>Request Recieved</div>&nbsp;:
                </div>
                <div className="detailsWrapper">
                  <div>Response Sent</div>&nbsp;:
                </div>
                <div className="detailsWrapper">
                  <div>Total Maintenance (Hr)</div>&nbsp;:
                </div>
                </div>
                <div style={{height:"100%",display:"flex",flexDirection:"column",justifyContent:'flex-start'}}>
                  {/* <Menu
                    id="long-menu"
                    MenuListProps={{
                      "aria-labelledby": "long-button",
                      style: {
                        padding: 0,
                      },
                    }}
                    anchorEl={anchorEl}
                    open={openAdminView}
                    onClose={handleClose}
                    PaperProps={{
                      style: {
                        maxHeight: ITEM_HEIGHT * (options.length + 1.5),
                        width: "auto",
                        color: "#fff",
                        borderRadius: 15,
                        boxShadow: "none",
                        textTransform: "uppercase",
                      },
                    }}
                  > */}
                  {options.map((option: adminOption) => [
                    nodeDetails?.statusId !== option.status && (

                      <MenuItemAdmin
                        key={option.id}
                        onClick={(event) =>
                          option.id !== 4 && handleMenu(event, option)
                        }
                        sx={{display:"flex",justifyContent:"space-between",flexDirection:"column"}}
                      >
                        <div style={{ backgroundColor: "#70CCF2",marginTop:"30px",fontFamily:"Mulish",padding: "10px", cursor: "pointer", fontWeight:600,borderRadius: "5px", width: "150px", textAlign: "center", marginLeft: "120px" }}>{option.name}</div>
                        {option.id === 4 && (
                          <input
                            type="file"
                            onChange={handleFileUpload}
                            style={{ position: "absolute", opacity: 0 }}
                          />
                        )}

                      </MenuItemAdmin>
                    ),
                  ])}
                  {/* </Menu> */}
                </div>
              </div>

              <ActionButton
                text={"Cancel"}
                width={96}
                height={60}
                radius={15}
                fontSize={19}
                fontWeight={800}
                color={"#E86B6C"}
                action={() => onCancel(false)}
              />
            </div>
          </NodeDetailsContainer>
        </Grid>
      </Grid>


      <Dialog
        open={deleteDialogOpen}
        onClose={handleDeleteCancel}
        aria-labelledby="delete-dialog-title"
        aria-describedby="delete-dialog-description"
      >
        <DialogTitle id="delete-dialog-title">Delete Node</DialogTitle>
        <DialogContent>
          <DialogContentText id="delete-dialog-description">
            Are you sure you want to delete this node? This action cannot be
            undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDeleteCancel} color="primary">
            Cancel
          </Button>
          <Button onClick={handleDeleteConfirmation} color="secondary" autoFocus>
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Backdrop>
  );
}

export default NodeDetails;
