import React from "react";
import NodeSetupList from "../feature/nodeSetup/NodeSetupList";

function NodeSetup() {

  const roleId = localStorage.getItem('roleId')
  return (
    <>
      <div style={roleId === "2" ? { display: "none" } : {}}>
        <NodeSetupList />
      </div>
    </>
  );
}

export default NodeSetup;
