import React from "react";
import TemplateLibraryList from "../feature/templateLibrary/TemplateLibraryList";

function TemplateLibrary() {
  return (
    <div>
      <TemplateLibraryList />
    </div>
  );
}

export default TemplateLibrary;
