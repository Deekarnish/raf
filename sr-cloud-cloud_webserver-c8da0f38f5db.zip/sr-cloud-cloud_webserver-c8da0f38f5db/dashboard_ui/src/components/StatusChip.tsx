import { Chip, Color } from "@mui/material";
import { styled } from "@mui/material/styles";
import React from "react";
import { NodeSetupStatus, DUTStatus, RequestPoolStatus } from "../types";

interface StatusChipButtonProps {
  statusText?: string;
  status: string;
  height: number;
  width?: number;
  fontSize?: number;
  topRadius?: number;
  borderRadius?: number;
  marginLeft?: number;
}

function StatusChipButton({
  statusText,
  status,
  height,
  width,
  fontSize = 11,
  topRadius,
  borderRadius = 100,
  marginLeft = 0,
}: StatusChipButtonProps) {
  const StatusChip = styled(Chip)(
    ({ theme }) => `
            background-color: ${statusColor(theme)};
            text-align: center;
            color: #FFF;
            height: ${height}px;
            width: ${width ? width + "px" : "auto"};
            border-radius: ${borderRadius}px;
            border-top-left-radius: ${topRadius === 0 ? topRadius : 100}px;
            border-top-right-radius: ${topRadius === 0 ? topRadius : 100}px;
            margin-left: ${marginLeft}px;
            .MuiChip-label {
                display: block;
                text-transform: uppercase;
                font-size: ${fontSize}px;
                font-weight: 700;
                
              },
          `
  );
  const statusColor = (theme: any) => {
    let color: Color = theme.status.active;
    switch (status) {
      case NodeSetupStatus[6]:
        color = theme.status.changeInitiated;
        break;
      case NodeSetupStatus[2]:
        color = theme.status.inactive;
        break;
      case NodeSetupStatus[3]:
        color = theme.status.running;
        break;
      case NodeSetupStatus[4]:
        color = theme.status.dutChanging;
        break;
      case NodeSetupStatus[10]:
      case DUTStatus[2]:
        color = theme.status.maintenance;
        break;
      case NodeSetupStatus[1]:
      case DUTStatus[1]:
        color = theme.status.active;
        break;
      case NodeSetupStatus[12]:
        color = theme.status.onHold;
        break;
      case NodeSetupStatus[11]:
      case DUTStatus[3]:
        color = theme.status.error;
        break;
      case NodeSetupStatus[9]:
      case NodeSetupStatus[13]:
        color = theme.status.notVerified;
        break;
      case NodeSetupStatus[8]:
        color = theme.status.verified;
        break;
      case NodeSetupStatus[5]:
        color = theme.status.engaged;
        break;
      case NodeSetupStatus[7]:
        color = theme.status.verOngoing;
        break;
      case RequestPoolStatus[0]:
        color = theme.status.awaiting;
        break;
      case RequestPoolStatus[1]:
        color = theme.status.completed;
        break;
      default:
        color = theme.status.active;
        break;
    }
    return color;
  };
  return <StatusChip label={statusText} />;
}

export default StatusChipButton;
