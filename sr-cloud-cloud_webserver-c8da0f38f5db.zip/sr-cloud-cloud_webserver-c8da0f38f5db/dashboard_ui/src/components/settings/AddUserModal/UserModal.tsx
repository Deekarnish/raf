import React, { useState } from "react";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import { InputLabel, Select, TextField } from "@mui/material";
import styled from "@emotion/styled";
import ActionButton from "../../ActionButton";
import { AddUserDetails } from "../../../types";
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import edit from '../../../assets/images/edit.png'

interface Props {
    handleClose: any;
    open: boolean;
    saveModalData: any;
    onInputChange: any;
    addUser: any;
    updateUserDetails:any;
    upDateId:any;
    editButton:any;
}

const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "25%",
    bgcolor: "#fff",
    boxShadow: 20,
    p: 3,
    minWidth: "20%",
    outline: "none",
    border: "5px solid black",
    borderRadius: "15px"
};

const Input = styled(TextField)`
  width: 100%;
  height: 30px;
  & .MuiInputBase-root {
    height: 30px;
    background-color: #efeff0;
    font-weight: 700;
    font-size: 19px;
    color: #9fa2b4;
    border: 1px solid #000000;
    border-radius: 0;
    & input {
      padding: 4px 5px;
      text-align: center;
      height: 22px;
    }
  }
`;

export default function UserModal({ handleClose, open, saveModalData, onInputChange, addUser,updateUserDetails,upDateId,editButton }: Props) {

    console.log(upDateId?.email,"dvshdvhdvdupdateId");
    

    return (
        <div>
            <Modal open={open} onClose={handleClose}>
                <Box sx={style}>
                    <div>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <h3 style={{ fontSize: "1.2rem", fontWeight: 500 }}>User Name</h3>
                            <div style={{ position: "relative", width: "300px", height: "30px" }}>
                                <Input placeholder="Fill in details" type="text"
                                    value={addUser?.username ? addUser?.username : upDateId?.userName}
                                    onChange={(e) => onInputChange("username", e.target.value)} />
                                
                            </div>
                        </div>

                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <h3 style={{ fontSize: "1.2rem", fontWeight: 500 }}>User Email</h3>
                            <div style={{ position: "relative", width: "300px", height: "30px" }}>
                                <Input placeholder="Fill in details" type="email"
                                    value={addUser?.email ? addUser?.email : upDateId?.email}
                                    onChange={(e) => onInputChange("email", e.target.value)} />
                                
                            </div>
                        </div>

                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <h3 style={{ fontSize: "1.2rem", fontWeight: 500 }}>Password</h3>
                            <div style={{ position: "relative", width: "300px", height: "30px" }}>
                                <Input placeholder="Fill in details" type="password"
                                    value={addUser.password}
                                    onChange={(e) => onInputChange("password", e.target.value)} />
                                
                            </div>
                        </div>

                        {/* <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <h3 style={{ fontSize: "1.2rem", fontWeight: 500 }}>Rold Id</h3>
                            <Input placeholder="fill in details" type="number"
                                value={addUser.roleId}
                                onChange={(e) => onInputChange("roleId", e.target.value)} />
                        </div> */}

                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                            <h3 style={{ fontSize: "1.2rem", fontWeight: 500 }}>RoleId</h3>
                            <FormControl sx={{ width: "65%" }}>
                                <InputLabel id="demo-simple-select-label">RoleId</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    value={addUser.roleId}
                                    label="RoleId"
                                    onChange={(e) => onInputChange("roleId", e.target.value)}
                                >
                                    <MenuItem value={1}>SuperUser</MenuItem>
                                    <MenuItem value={2}>TAFUser</MenuItem>
                                    <MenuItem value={3}>TLOUser</MenuItem>
                                </Select>
                            </FormControl>

                        </div>

                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "20px" }}>
                            <ActionButton
                                text={"Cancel"}
                                width={96}
                                height={60}
                                radius={15}
                                fontSize={19}
                                fontWeight={800}
                                color={"#E86B6C"}
                                action={handleClose}
                            />

                            <ActionButton
                                text={"Save"}
                                width={96}
                                height={60}
                                radius={15}
                                fontSize={19}
                                fontWeight={800}
                                color={"#70CCF2"}
                                action={editButton ? saveModalData : () => updateUserDetails(upDateId.id)}
                            />
                        </div>
                    </div>
                </Box>
            </Modal>
        </div>
    );
}