import React from "react";
import { Button, TextField } from "@mui/material";
import { styled } from "@mui/material/styles";
import search from "../assets/images/search.png";

interface SearchBarProps {
  width?: number;
  height?: number;
  action?: () => void;
  searchTerm: string;
  handleSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const SearchText = styled(TextField)`
    margin-left: 12px;
    height: 24px;
    width: 275px;
    border-radius: 100px;
    background-color: #C4C4C4;
    line-height: 24px;
    border: none;
    & .MuiInput-root:before, & .MuiInput-root:after, & .MuiInput-root:hover:not(.Mui-disabled, .Mui-error):before{
        border: 0
    }
    & .MuiInput-input {
        height: 20px;
        padding: 2px 8px;
    color: #FFF;
    font-size: 11px;
    font-weight: 600;

    }
  `;

function SearchBar({ width = 238, height = 40, action, searchTerm, handleSearchChange }: SearchBarProps,) {
  return (
    <>
      <img src={search} alt="search" />
      <SearchText placeholder="search" id="outlined-basic" variant="standard" value={searchTerm} onChange={handleSearchChange} />
    </>
  );
}

export default SearchBar;
