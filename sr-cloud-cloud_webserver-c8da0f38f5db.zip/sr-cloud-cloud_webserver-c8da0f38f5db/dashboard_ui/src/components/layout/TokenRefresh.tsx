import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import { createRequest } from "../../services/ApiServices";

const parseJwt = (token: string) => {
  try {
    return JSON.parse(atob(token.split(".")[1]));
  } catch (e) {
    return null;
  }
};

interface tokenProps {
  logOut: () => void;
}

const TokenRefresh = ({ logOut }: tokenProps) => {
  let location = useLocation();
  let timeOutId: any;

  useEffect(() => {
    const token = sessionStorage.getItem("token");
    if (token) {
      const decodedJwt = parseJwt(token);
      if (decodedJwt.exp * 1000 < Date.now()) {
        clearTimeout(timeOutId);
        refreshToken(token);
      }
      if (location?.state?.token) {
        checkForTokenExpiry(decodedJwt, token);
      }
    }
  }, [location]);

  const checkForTokenExpiry = (decodedJwt: any, token: string) => {
    const now = Date.now();
    const interval = Math.max(0, Math.ceil(decodedJwt.exp * 1000 - now));
    timeOutId = setTimeout(() => {
      refreshToken(token);
    }, interval);
  };

  const refreshToken = (token: string) => {
    clearTimeout(timeOutId);
    createRequest({
      api: "refreshUserToken",
      method: "create",
      body: {
        token,
        refreshToken: sessionStorage.getItem("refreshToken"),
      },
    })
      ?.then(async (res) => {
        if (res.data.token) {
          sessionStorage.setItem("token", res.data.token);
          const decodedJwt = parseJwt(res.data.token);
          checkForTokenExpiry(decodedJwt, token);
        }
        if (res.data.refreshToken) {
          sessionStorage.setItem(
            "refreshToken",
            JSON.stringify(res.data.refreshToken)
          );
        }
      })
      ?.catch((err) => {
        logOut();
      });
  };

  return <></>;
};

export default TokenRefresh;
