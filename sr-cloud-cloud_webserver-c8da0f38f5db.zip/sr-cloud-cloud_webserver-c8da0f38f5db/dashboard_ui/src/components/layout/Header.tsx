import React, { useEffect, useState } from "react";
import {
  Divider,
  Avatar,
  Badge,
  Box,
  IconButton,
  styled,
  Toolbar,
  Typography,
} from "@mui/material";
import header from "../../assets/images/header.png";
import notification from "../../assets/images/notification.png";
import { Navigate, useLocation, useNavigate } from "react-router-dom";
import LogoutIcon from '@mui/icons-material/Logout';
import Logout from "@mui/icons-material/Logout";

const LogoImage = styled(Avatar)`
  padding: 1.5px;
  background-color: #fff;
`;

const ItemDivider = styled(Divider)`
  margin-left: 32px !important;
  margin-right: 15px !important;
  height: 32px;
`;

function Header() {

    const location = useLocation();
    const navigate = useNavigate();

    const [pageTitle, setPageTitle] = useState('');
    
    useEffect(() => {
        if(location?.state?.title) {
          setPageTitle(location.state.title);
        }
    },[location]);

    const logOut = () => {
      sessionStorage.clear();
      localStorage.removeItem('roleId')
      navigate('/login');
    }
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Toolbar disableGutters>
        <Typography
          variant="h1"
          component="div"
          sx={{ flexGrow: 1, textAlign: "left" }}
        >
          {pageTitle}
        </Typography>
        <Badge variant="dot" color="info">
            <img src={notification} alt="notification" />
        </Badge>
        <ItemDivider orientation="vertical"/>
        <Typography variant="h6">{sessionStorage.getItem('user')}</Typography>
        <IconButton
          size="large"
          aria-label="account of current user"
          color="inherit"
        >
          <LogoImage src={header} alt="logo" />
        </IconButton>
        <IconButton
          size="large"
          aria-label="logout"
          color="inherit"
          onClick={() => logOut()} 
        >
            <LogoutIcon />
        </IconButton>
      </Toolbar>
    </Box>
  );
}

export default Header;
