import { createTheme } from "@mui/material/styles";
import "./assets/fonts/Mulish/Mulish-Regular.ttf";

declare module "@mui/material/styles" {
  interface Theme {
    status: {
      changeInitiated: React.CSSProperties['color'],
      maintenance: React.CSSProperties['color'],
      active: React.CSSProperties['color'],
      onHold: React.CSSProperties['color'],
      error: React.CSSProperties['color'],
      notVerified: React.CSSProperties['color'],
      verified: React.CSSProperties['color'],
      engaged: React.CSSProperties['color'],
      verOngoing: React.CSSProperties['color'],
    }
  }
  interface ThemeOptions {
    status: {
      changeInitiated: React.CSSProperties['color'],
      maintenance: React.CSSProperties['color'],
      active: React.CSSProperties['color'],
      onHold: React.CSSProperties['color'],
      error: React.CSSProperties['color'],
      notVerified: React.CSSProperties['color'],
      verified: React.CSSProperties['color'],
      engaged: React.CSSProperties['color'],
      verOngoing: React.CSSProperties['color'],
      awaiting: React.CSSProperties['color'],
      completed: React.CSSProperties['color'],
    }
  }
}

export const theme = createTheme({
  status: {
    changeInitiated: '#F178B6',
    maintenance: '#FEC400',
    active: '#29CC97',
    onHold: '#41C7FE',
    error: '#F12B2C',
    notVerified: '#7879F1',
    verified: '#5D5FEF',
    engaged: '#FEC400',
    verOngoing: '#F178B6',
    awaiting: '#FEC400',
    completed: '#29CC97'
  },
  palette: {
    primary: {
      main: "#363740",
    },
    secondary: {
      main: "#FFFFFF",
    },
    background: {
      default: "#E5E5E5",
      paper: "#363740",
    },
    text: {
      primary: "#252733",
      secondary: "#C5C7CD",
    },
    info: {
      main: "#3751FF",
    },
    divider: "#DFE0EB",
    grey: {
      100: "rgba(159, 162, 180, 0.08)",
      700: "#A4A6B3",
      800: "#DDE2FF",
      900: "#9FA2B4",
    },
  },
  typography: {
    fontFamily: "Mulish, Arial",
    fontSize: 14,
    h1: {
      fontSize: "1.5rem",
      fontWeight: "bold",
    },
    h2: {
      fontSize: "1.19rem",
      fontWeight: "bold",
    },
    h3: {
      fontSize: "1.35rem",
      fontWeight: "700",
    },
    h6: {
      fontSize: "1rem",
      fontWeight: "700",
    },
  },
  components: {
    MuiTableCell: {
      styleOverrides: {
        head: {
          fontSize: '14px',
          color: '#9FA2B4',
          fontWeight: 'bold'
        },
        body: {
          fontSize: '14px',
          color: '#252733',
          fontWeight: '500'
        }
      }
    },
    MuiPaper: {
          styleOverrides: {
            root: {
              color: "#FFF",
            },
          },
        },
  }
  // components: {
  //   MuiPaper: {
  //     styleOverrides: {
  //       root: {
  //         backgroundColor: "#FFF",
  //       },
  //     },
  //   },
  // },
});
